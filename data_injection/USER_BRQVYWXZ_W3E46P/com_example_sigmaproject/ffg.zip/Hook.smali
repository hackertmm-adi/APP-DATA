Hook For MainActivity :-     
      
      invoke-static {p0}, Lcom/adi/hackertmm/dilog/hackertmm_pin_dilog;->hackertmm(Landroid/app/Activity;)V