1. Add this to your AndroidManifest.xml inside the <application> tag: ( You get It Via Our website https://hackertmm.rf.gd/ )

<meta-data
    android:name="config_ch"
    android:value="Your-encrypted-user-id" />
    
2. Add tha Lib Acoarding To Your Application Lib Like If Your Application Is arm64-v8a Then Add arm64-v8a Lib Folder Annd If Your Application is armeabi-v7a Then Add armeabi-v7a Lib Folder If Your Application Support Both Then Add Both Folder
    
3. Hook :-     invoke-static {p0}, Lcom/adi/hackertmm/dilog/hackertmm_pin_dilog;->hackertmm(Landroid/app/Activity;)V

4. And Add Your Image In Asstes Reanme To icon